window.onload = function() {

    // animationTimeout(function() {
    //     addClass(gid('example-elem'), {
    //         class: 'example-class',
    //         remove: 2000
    //     });
    // }, 1500);

    // fade({
    //     id: 'example-elem',
    //     delay: 3000,
    //     fps: 120,
    //     calcStep: 0.02,
    //     direction: 'out',
    // });

};
