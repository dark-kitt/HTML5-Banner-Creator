<?php
$banner_config = [
	$main = [
		"directory" => "/media/sf_workspace/banner-creator/projects/client/product/campagne/motif/300x250",
		"project_path" => "/media/sf_workspace/banner-creator/projects/client/product/campagne",
		"width" => 300,
		"height" => 250,
		"namespace" => false,
		"js_files" => [
			BASE_JS
		]
	]

];