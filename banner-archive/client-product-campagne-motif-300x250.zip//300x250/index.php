<div id="stage">
    <section id="sequence-one">

    </section>
</div>

<div id="click-layer"></div>
